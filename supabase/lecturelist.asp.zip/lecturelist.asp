<!DOCTYPE html>
<!-- #include virtual = "/dbconn/GetDbConStr.asp" -->
<!-- #include file="../inc_new5/inc_top_01.asp" --> 
<!-- #include virtual = "/admin/Function.asp" -->




<div class="license-list">
	<div class="inr">
		<div class="sub-top">
			<!-- page navigatin -->
			<div class="area_navigation" >
				<ul>
					<li><a href="/"><img src="/images_new5/content/ic-home.svg" /></a></li>
					<li>������û</li>
					<li></li>
				</ul>
			</div>
			<!--// page navigatin -->	
			<div class="sub-visual">
				<div class="txt">
					<h3>����������� ���ĵ�� �ڰ���</h3>
					<p>����� �����Ʒü����� ����������� �ڰ��������� Ȯ���غ�����!</p>
				</div>
				<div class="img"><img src="../../images_new5/content/sub-visual__license.png"></div>
			</div>
		</div>

		<div class="sub-bottom">
			<div class="area-side">
				<div class="area_lnb">
					<ul>
					
						<li><a href="?" data-id="all"><span>��ü����</a></li>
						<li><a href="?cateID=01" data-id="01"><span>�ǹ�/���� ����</span></a></li>
						<li><a href="?cateID=02" data-id="02"><span>�ɸ�������</span></a></li>
						<li><a href="?cateID=03" data-id="03"><span>�Ƶ�/���� ����</span></a></li>
						<li><a href="?cateID=04" data-id="04"><span>�������</span></a></li>
						<li><a href="?cateID=05" data-id="05"><span>����/�ǰ� ����</span></a></li>
						<li><a href="?cateID=06" data-id="06"><span>���� ������</span></a></li>
						<li><a href="?cateID=07" data-id="07"><span>��Ƽ/���� ����</span></a></li>
						<li><a href="?cateID=08" data-id="08"><span>����/��ȸ����</span></a></li>
						<li><a href="?cateID=09" data-id="09"><span>Ŀ�ǰ���</span></a></li>
						<li><a href="?cateID=10" data-id="10"><span>ȯ��������</span></a></li>
						<li><a href="?cateID=11" data-id="11"><span>�����ð���</span></a></li>
						<li><a href="?cateID=12" data-id="12"><span>��������</span></a></li>
						<li><a href="?cateID=13" data-id="13"><span>��������</span></a></li>
						<li><a href="?cateID=14" data-id="14"><span>IT����</span></a></li>
						<li><a href="?cateID=15" data-id="15"><span>�ݷ�����</span></a></li>
						<li><a href="?cateID=16" data-id="16"><span>���Ϲ�����</span></a></li>
										</ul>  	
				</div>
				<div class="kakao"><a href=""><img src="../../images_new5/content/left-kakao.jpg"></a></div>
				<div class="bank-account">
					<h3>�Աݰ���</h3>
					<div class="bank-logo"><img src="../../images_new5/main/ic-bank.svg"></div>
					<h4>140-014-910339</h4>
					<em>������ : �ѱ������Ʒü���</em>
				</div>
				<div class="remote"><a href=""><h3>�������� ����</h3></a></div>
			</div>
			<div class="area-content">
				<h2>��ü����</h2>

              <!--#include file="../inc/inc_loginfo.asp" -->
		
				<!-- ����з�--
                        <table width="760" border="0" cellspacing="0" cellpadding="0">
							<tr height="33"> 
							 <td width="60" height="60" rowspan="3" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?">��ü����</a></td>
							 <td width="160" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=01">���л�, ���ػ����� ����</a></td>
							 <td width="150" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=02">�ɸ���������� ����</a></td>
							 <td width="150" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=03">����������� ����</a></td>
                             <td width="170" class="text-bold" style="border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=04">���������� ����</a></td>
                            </tr>

							<tr height="33"> 
							 <td width="160" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=05">Ŀ�������� ����</a></td>
							 <td width="150" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=06">�������������� ����</a></td>
                             <td width="150" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=07">��Ƽ������ ����</a></td>
							 <td width="170" class="text-bold" style="border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=08">û�ҳ����</a></td>
                            </tr>

							<tr height="33"> 
							 <td width="160" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=09">�������������� ����</a></td>
							 <td width="150" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=10">�μ����������� ����</a></td>
                             <td width="150" class="text-bold" style="border-right:1px solid #ccc; border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=18">�����ذ��������� ����</a></td>
                             <td width="170" class="text-bold" style="border-bottom:1px solid #ccc;" align="center" bgcolor="f3f9ff"><a href="?cateID=19">�ǹ��ɾ� ���������� ����</a></td>
                            </tr>

		                </table>
				   
		
				
				<!-- ����з�--e -->

				


		
           


			<script language="javascript">
				function sendit()
				{
					var chk=false;
					
					if (regFrm.gisu_idx.length >  1)
					{
						for(i=0;i<regFrm.gisu_idx.length;i++)
							if(regFrm.gisu_idx[i].checked) chk = true;		
					
					
						if(!chk)
						{
							alert("��û������ ������ �ּ���.")
							return false;
						}
					}
					else
					{
						if (!regFrm.gisu_idx.checked)
						{
							alert("��û������ ������ �ּ���.")
							return false;
						}
					}	
					
					return true;
				}
			</script>

			<!--  2016-07-04 ���ȯ ���� ������û�� �ٷ� �������� -->
			<%
			GroupCode = Domain_Group

'			SQL_member = "Select mem_recomId From GtblMemberInfo Where mem_id = '"&Session("userid")&"'"
'			Set MemRs  = adoConn.Execute(SQL_member)
'
'			SQL_Admin_member = "Select mem_Username From GtblAdminMember Where mem_SGrpId = '"&Domain_Group&"' and mem_LGrpId = 'recommendAdmin' and mem_Username = '"& MemRs("mem_recomId") &"'"
'			Set Admin_MemRs  = adoConn.Execute(SQL_Admin_member)
'
'			'If MemRs("mem_recomId") = Admin_MemRs("mem_Username") then
'			if Admin_MemRs.Eof Then 	
'				Response.write "<form name='regFrm' method='post' action='lecture_select.asp' onsubmit='return sendit()'>"
'			Else
'				Response.write "<form name='regFrm' method='post' action='lecture_direct_ok.asp' onsubmit='return sendit()'>"
'			End If
			%>

			<form name='regFrm' method='post' action='lecture_direct_ok.asp' onsubmit='return sendit()'>
			<input type="hidden" name="gopaymethod" value="Coupon">
			 <ul class="lecture-list">

			<%
			'########################## ������û ���� ���� ���� ########################################
			cate_ID = request("cateID")
			'SQL = "Select * From vwGisuClassTypeSortLecture Where gisu_Groupcode='"&GroupCode&"' and gisu_Opt='1' and gisu_num='0' and lec_lecOpt='1'"
			SQL = "Select * From vwGisuClassTypeSortLecture Where gisu_Groupcode='"&GroupCode&"' and gisu_Opt='1' and gisu_num='0' "
				If cate_ID <> "" Then 
					SQL = SQL & " and lec_dir='"& cate_ID &"' "
				End If 

			
				If cate_ID = "14" Then 
					SQL = SQL & " and Convert(int,gisu_appSdate)<="&Replace(date,"-","")&" and Convert(int,gisu_appEdate) >=" & Replace(date,"-","")	& " order by lec_lecName asc"
				ElseIf cate_ID = "17" Then 
					SQL = SQL & " and Convert(int,gisu_appSdate)<="&Replace(date,"-","")&" and Convert(int,gisu_appEdate) >=" & Replace(date,"-","")	& " order by lec_lecCode asc"
				Else 
					SQL = SQL & " and Convert(int,gisu_appSdate)<="&Replace(date,"-","")&" and Convert(int,gisu_appEdate) >=" & Replace(date,"-","")	& " order by lec_lecName asc"
				End If 


If request.ServerVariables("REMOTE_HOST") = "49.142.32.179" Then
	'Response.write SQL&"<BR>"
	'Response.End 
End If
			
			
			
			Set  gisuRs = adoConn.Execute(SQL)							
			
			if gisuRs.Eof then
			%>
				<li class="nodata">��û������ ���°� �����ϴ�.</li>



			<%
			else 
				gisuidxArr = Split(Request("gisu_idx"),",")
				
				Do Until gisuRs.Eof
			
				idxChk = false
	
				if Ubound(gisuidxArr) > -1 then	'################# �����߰� ���
					for i=0 to Ubound(gisuidxArr)
						if Clng(Trim(gisuidxArr(i))) = Clng(gisuRs("gisu_idx")) then idxChk = true
					Next						
				end if
			'########################### ���� �������� �Ǵ� ###########################################
	'		SQL = "Select app_idx From GtblApplianceOrderInfo Where app_groupCode='"&GroupCode&"' and "
	'		SQL = SQL & "app_lecCode='"&gisuRs("gisu_lecCode")&"' and "
	'		SQL = SQL & "app_userid='"&Session("userid")&"' and (app_status='1' or app_status='2')"
			'Response.Write SQL
	'	    Set chkRs = adoConn.Execute(SQL)			
			%>
                          <li> 
							<%
							SQL_pic = "select lec_idx, lec_attachFile from GtblLectureInfo where lec_lecCode = '"&gisuRs("gisu_lecCode")&"'"
							Set  picRs = adoConn.Execute(SQL_pic)							
							'Response.write picRs("lec_attachFile")&"-"&picRs("lec_idx")&"-"&gisuRs("gisu_lecCode")
							%>
							<div class="lecture-card-wrapper">
								<a href="/lecture/<%=gisuRs("lec_lecCode")%>.asp">
									<div class="img">
										<img src="http://vod.klli.kr/Common/apply_list_img/<%=gisuRs("gisu_lecCode")%>.jpg">
									</div>
								</a>
								<div class="txt">
									<div class="top">
										<div class="title-price-row">
											<h3 class="lec-name">
												<% If gisuRs("lec_idx") = "91" Then %>
													<%=gisuRs("lec_lecname")%>(<b>������������</b>)<!-- <br>[<%=gisuRs("gisu_lecCode")%>] -->
												<% Else %>
													<% If gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0002" Or  gisuRs("lec_lecCode") = "manager_2017_01_01_01_02_0078" Or  gisuRs("lec_lecCode") = "manager_2017_01_01_01_02_0079" Or  gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0003" Or gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0004" Or gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0005" Or gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0007" Or gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0008" Then %>

														<span id=mytext><img src="/images/hot.jpg"></span>
														<%=gisuRs("lec_lecname")%>(<%=gisuRs("gisu_name")%>) 
														

													<% Else %>
														<%=gisuRs("lec_lecname")%>(<%=gisuRs("gisu_name")%>)
													<% End If %>
												<% End If %>
												<% if gisuRs("gisu_displayOpt")="1" then %>
													<img src="/application/images/icon_ing.gif" border="0" align="absmiddle"> 
												<% end If %>
											</h3>
											<div class="price-inline">
												<span class="original-price">400,000��</span>
												<span class="discount-price">0��</span>
											</div>
										</div>
									</div>
									<div class="bottom-right-area">
										<ul class="info-list">
											<li><em>��米��</em><span><%=gisuRs("lec_tutorName")%> ����</span></li>
											<li><em>�������</em><span>�¶��� ����</span></li>
											<li><em>���ǽð�</em><span>��ü �� 20�ð�</span></li>
											<li><em>�ֹ���û</em><span>��ȭü��������</span></li>
										</ul>
										<div class="btn-area">
									<ul class="btn-list-vertical">
										<li class="btn-line"><a href="/service/counsel.asp">����û�ϱ�</a></li>
										<li class="btn-default">
										<% if gisuRs("lec_samplePartNum")<>"" then %>
											<a href="javascript:lecture_open('http://vod.klli.kr/player/player_sample.asp?groupcode=<%=Domain_group%>&lec_idx=<%=gisuRs("lec_idx")%>&partNum=<%=gisuRs("lec_samplePartNum")%>&userid=khri1&gisuYear=2017&gisuNum=52&injection=except','lecture_1','1280','900');">���ǻ��ú���</a>
										<% end If %>
										</li>
										<li class="btn-select">
											<label class="checkbox_label">
												<span class="select-text">���� �����ϱ�</span>
												<input type="Checkbox" 
													name="gisu_idx" 
													value="<%=gisuRs("gisu_idx")%>"
													class="lecture-checkbox"
													data-lecture-id="<%=gisuRs("gisu_idx")%>"
													data-lecture-name="<%
														If gisuRs("lec_idx") = "91" Then
															Response.Write Server.HTMLEncode(gisuRs("lec_lecname") & "(������������)")
														Else
															If gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0002" Or gisuRs("lec_lecCode") = "manager_2017_01_01_01_02_0078" Or gisuRs("lec_lecCode") = "manager_2017_01_01_01_02_0079" Or gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0003" Or gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0004" Or gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0005" Or gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0007" Or gisuRs("lec_lecCode") = "manager_2019_01_01_01_02_0008" Then
																Response.Write Server.HTMLEncode(gisuRs("lec_lecname") & "(" & gisuRs("gisu_name") & ")")
															Else
																Response.Write Server.HTMLEncode(gisuRs("lec_lecname") & "(" & gisuRs("gisu_name") & ")")
															End If
														End If
													%>"
													data-lecture-price="0">
												<span class="checkbox_icon"></span>
											</label>
										</li>
									</ul>
									</div>
								</div>
							</div>
                           
                          </li>
			<% 
			gisuRs.MoveNext
			Loop
			end If
			%>


                        </ul>

					  

							<script type="text/javascript">
							<!--
							function login(){
								result = confirm('������û�� ���ؼ� ������ ȸ�������� �ʿ��մϴ�.\n\nȸ�������� �Ͻðڽ��ϱ�?')
								if(result == true){
									document.regFrm.action="/member/login_new.asp";
									document.regFrm.submit();
								}
							}
							//-->
							</script>


							<% If session("userId") = "" Then %>
								<input class="btn-submit" type="submit" onclick="login()" style="cursor:pointer" border="0" onFocus="this.blur()" value="���ð��� ������û">
							<% Else %>
								<input class="btn-submit" type="submit" onFocus="this.blur()" value="���ð��� ������û">
							<% End If %>


					  
				


			</div>


		</div>
	</div>
</div>

<!-- ������ ���� �ϴ� �� -->
<div id="selected-lectures-bar" style="display:none; position:fixed; bottom:0; left:0; right:0; background:#e9f3ff; color:#fff; padding:30px 20px; z-index:1000; box-shadow:0 -2px 10px rgba(0,0,0,0.2);">
	<div style="max-width:1200px; margin:0 auto; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:15px;">
		<div style="display:flex; align-items:center; gap:20px; flex:1;">
			<span style="font-weight:bold; color:#0078ff; font-size:16px; display:flex; align-items: center; gap:10px; justify-content: center; width: 100%;">������ ���� <span id="selected-count" style="font-size: 40px;">0</span><span style="color:#7e98b4">��</span></span>
			<div id="selected-lectures-list" style="display:flex; gap:10px; flex-wrap:wrap;">
				<!-- ������ ���� ����� ���⿡ �������� �߰��� -->
			</div>
		</div>
		<div style="display:flex; align-items:center; gap:20px;">
			<div style="text-align:right; display:flex; align-items: center; justify-content: center; gap:10px;">
				<div style="text-decoration:line-through; opacity:0.7; font-size:14px; color:#7e98b4"><span#0066cc id="total-original-price"">400,000</span>��</div>
				<div style="font-size:18px; font-weight:bold; display:flex; align-items: center; gap:10px; justify-content: center;"><span id="total-price" style="font-size: 40px; color:#0078ff;">0</span><span style="color:#7e98b4">��</span></span></div>
			</div>
			
			
		<% If session("userId") = "" Then %>
			<button type="button" onclick="onclick=login()" style="background:#0078ff; color:#fff; border:none; padding:12px 30px; border-radius:5px; font-weight:bold; cursor:pointer;  font-weight:700; font-size:20px;">���ð��� ������û</button>
		<% Else %>
			<button type="button" onclick="document.regFrm.submit();" style="background:#0078ff; color:#fff; border:none; padding:12px 30px; border-radius:5px; font-weight:bold; cursor:pointer;  font-weight:700; font-size:20px;">���ð��� ������û</button>
		<% End If %>
			
			
		</div>
	</div>
</div>

<!--#include file="../inc_new5/quick.asp" -->
<!--#include file="../inc_new5/inc_bottom.asp" -->




<script>
$(document).ready(function() {
    // URL���� cateID �Ķ���� ����
    const urlParams = new URLSearchParams(window.location.search);
    const cateID = urlParams.get('cateID') || 'all';

    $('.area_lnb li a').each(function() {
        if ($(this).data('id') == cateID) { 
            $(this).addClass('on');
        } else {
            $(this).removeClass('on');
        }
    });

    // ������ ���� ���� ��ü
    const selectedLectures = {};

    // üũ�ڽ� ���� �̺�Ʈ
    $(document).on('change', '.lecture-checkbox', function() {
        const checkbox = $(this);
        const lectureId = checkbox.data('lecture-id');
        const lectureName = checkbox.data('lecture-name');
        const lecturePrice = parseInt(checkbox.data('lecture-price')) || 0;
        const $label = checkbox.closest('.checkbox_label');

        if (checkbox.is(':checked')) {
            // ���� �߰�
            selectedLectures[lectureId] = {
                id: lectureId,
                name: lectureName,
                price: lecturePrice
            };
            $label.addClass('checked');
        } else {
            // ���� ����
            delete selectedLectures[lectureId];
            $label.removeClass('checked');
        }

        updateSelectedBar();
    });

    // �ϴ� �� ������Ʈ �Լ�
    function updateSelectedBar() {
        const count = Object.keys(selectedLectures).length;
        const $bar = $('#selected-lectures-bar');
        const $list = $('#selected-lectures-list');
        const $count = $('#selected-count');
        
        if (count > 0) {
            $bar.show();
            $count.text(count);
            
            // ������ ���� ��� ������Ʈ
            $list.empty();
            let totalPrice = 0;
            
            let totalOriginalPrice = 0;
            $.each(selectedLectures, function(id, lecture) {
                totalPrice += lecture.price;
                totalOriginalPrice += 400000; // �� ���Ǵ� ���� ���� 400,000��
                const $item = $('<div>')
                    .css({
                        'background': '#fff',
                        'color': 'black',
						'font-weight': '600',
                        'padding': '8px 15px',
                        'border-radius': '5px',
                        'font-size': '14px',
                        'display': 'flex',
                        'align-items': 'center',
                        'gap': '10px'
                    })
                    .html('<span>' + lecture.name + '</span><button type="button" onclick="removeLecture(\'' + id + '\')" style="background:none; border:none; color:black; cursor:pointer; font-size:18px; padding:0; width:20px; height:20px; line-height:1;">��</button>');
                $list.append($item);
            });
            
            $('#total-price').text(totalPrice.toLocaleString());
            $('#total-original-price').text(totalOriginalPrice.toLocaleString());
        } else {
            $bar.hide();
        }
    }

    // ���� ���� �Լ� (����)
    window.removeLecture = function(lectureId) {
        const $checkbox = $('.lecture-checkbox[data-lecture-id="' + lectureId + '"]');
        $checkbox.prop('checked', false);
        $checkbox.closest('.checkbox_label').removeClass('checked');
        delete selectedLectures[lectureId];
        updateSelectedBar();
    };

    // ������ �ε� �� �̹� ���õ� üũ�ڽ� Ȯ��
    $('.lecture-checkbox:checked').each(function() {
        const checkbox = $(this);
        const lectureId = checkbox.data('lecture-id');
        const lectureName = checkbox.data('lecture-name');
        const lecturePrice = parseInt(checkbox.data('lecture-price')) || 0;
        const $label = checkbox.closest('.checkbox_label');
        
        selectedLectures[lectureId] = {
            id: lectureId,
            name: lectureName,
            price: lecturePrice
        };
        $label.addClass('checked');
    });
    
    updateSelectedBar();
});

</script>
